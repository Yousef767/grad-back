<?php

use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\Post\PostController;
use App\Http\Controllers\Post\PostImageController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Posts Routes
|--------------------------------------------------------------------------
|
| This section contains routes related to posts management.
|
*/



/**
 * Manage posts.
 * Requires privileged User.
 */
Route::middleware(['auth:sanctum', 'privilegedUsers'])->prefix('posts/')->group(function () {

    /**
     * Retrieve posts created by the authenticated user.
     * Method: GET
     * URI: /myposts
     * Controller: PostController@userPosts
     */
    Route::get('/myposts', [PostController::class, 'userPosts']);

    /**
     * Store a new post.
     * Method: POST
     * URI: /posts
     * Controller: PostController@store
     */
    Route::post('/', [PostController::class, 'store']);

    /**
     * Update an existing post.
     * Method: PUT
     * URI: /posts/{post}
     * Controller: PostController@update
     */
    Route::put('/{post}', [PostController::class, 'update']);

    /**
     * Delete a post.
     * Method: DELETE
     * URI: /posts/{post}
     * Controller: PostController@destroy
     */
    Route::delete('/{post}', [PostController::class, 'destroy']);

});



