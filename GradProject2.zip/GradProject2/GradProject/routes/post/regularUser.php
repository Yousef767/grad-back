<?php

use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\Post\PostController;
use App\Http\Controllers\Post\PostImageController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Posts Routes
|--------------------------------------------------------------------------
|
| This section contains routes related to posts management.
|
*/

// Public routes
Route::prefix('posts')->group(function () {

    /**
     * Retrieve all posts.
     * Method: GET
     * URI: /posts
     * Controller: PostController@index
     */
    Route::get('/', [PostController::class, 'index']);

    /**
     * Show a specific post.
     * Method: GET
     * URI: /posts/{post}
     * Controller: PostController@show
     */
    Route::get('/{post}', [PostController::class, 'show'])
        ->where('postId', '^(?!myposts$).*$'); // Exclude 'myposts' from being considered as an ID


    /**
     * Manage favorites for authenticated users.
     * Requires authentication.
     */
    Route::middleware(['auth:sanctum'])->group(function () {

        /**
         * Add a post to favorites.
         * Method: POST
         * URI: /posts/{post}/favorite
         * Controller: FavoriteController@addToFavorites
         */
        Route::post('/{post}/favorite', [FavoriteController::class, 'addToFavorites']);

        /**
         * Remove a post from favorites.
         * Method: DELETE
         * URI: /posts/{post}/favorite
         * Controller: FavoriteController@removeFromFavorites
         */
        Route::delete('/{post}/favorite', [FavoriteController::class, 'removeFromFavorites']);

    });

});

