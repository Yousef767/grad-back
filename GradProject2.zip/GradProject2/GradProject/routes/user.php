<?php

use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\User\UserController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:sanctum'])->prefix('user/{user:username}')->group(function () {

    Route::get('/', [UserController::class, 'show'] );
    Route::put('/', [UserController::class, 'update']);
    Route::delete('/', [UserController::class, 'destroy']);

    Route::get('/favorites',[FavoriteController::class, 'getFavorites']);

});
