<?php

use App\Http\Controllers\ContactController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response()->json([
        'message' => 'Hello World!'
    ]);
});

require __DIR__.'/user.php';
require __DIR__.'/auth.php';
require __DIR__ . '/post/seller.php';
require __DIR__ . '/post/regularUser.php';
require __DIR__.'/admin.php';

Route::post('/contact-us', [ContactController::class, 'storeContactForm']);
