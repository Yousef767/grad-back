<?php echo e($slot); ?>

<?php /**PATH C:\Users\omar\Desktop\GradProject\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>