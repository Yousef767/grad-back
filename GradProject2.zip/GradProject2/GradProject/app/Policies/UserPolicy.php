<?php

namespace App\Policies;

use App\Models\User;

class UserPolicy
{
    public function view(User $user, User $model)
    {
        return $user->user_type === 'admin' || $user->id === $model->id;
    }

    public function update(User $user, User $model)
    {
        return $user->user_type === 'admin' || $user->id === $model->id;
    }

    public function delete(User $user, User $model)
    {
        return $user->user_type === 'admin' || $user->id === $model->id;
    }
}
