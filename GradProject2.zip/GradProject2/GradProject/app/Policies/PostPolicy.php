<?php

namespace App\Policies;

use App\Models\Post\Post;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Auth\Access\Response;


class PostPolicy
{
    use HandlesAuthorization;

    public function update(User $user, Post $post): Response
    {
        return $user->username === $post->posted_by || $user->user_type === 'admin'
            ? Response::allow()
            : $this->denyWithStatus(401);
    }

    public function delete(User $user, Post $post): Response
    {
        return $user->username === $post->posted_by || $user->user_type === 'admin'
            ? Response::allow()
            : $this->denyWithStatus(401);
    }
}
