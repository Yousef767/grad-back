<?php

namespace App\Models\Post;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'post_for',
        'posted_by',
        'description',
        'post_category',
        'city',
        'address',
        'num_of_rooms', // Assuming 'room' refers to the number of rooms in an apartment
        'num_of_bedrooms',
        'num_of_kitchens',
        'num_of_bathrooms',
        'price',
        
    ];

    public function scopeFilter($query, $filters)
    {

        // Input validation
        $numericFilters = ['min_price', 'max_price', 'num_of_bedrooms', 'num_of_kitchens', 'num_of_bathrooms', 'num_of_rooms'];
        foreach ($numericFilters as $filter) {
            if (isset($filters[$filter]) && is_numeric($filters[$filter])) {
                // Valid numeric filter
                if (in_array($filter, ['min_price', 'max_price'])) {
                    // Price filters should be positive values
                    $filters[$filter] = max(0, $filters[$filter]);
                }
            } else {
                unset($filters[$filter]); // Remove invalid or non-numeric filters
            }
        }

        if (isset($filters['min_price'])) {
            $query->where('price', '>=', $filters['min_price']);
        }
        if (isset($filters['max_price'])) {
            $query->where('price', '<=', $filters['max_price']);
        }

        if (isset($filters['city'])) {
            $query->where('city', $filters['city']);
        }

        if (isset($filters['post_category'])) {
            $query->where('post_category', $filters['post_category']);
        }

        $numericFilters = ['num_of_bedrooms', 'num_of_kitchens', 'num_of_bathrooms', 'num_of_rooms'];
        foreach ($numericFilters as $filter) {
            if (isset($filters[$filter])) {
                $query->where($filter, $filters[$filter]);
            }
        }

        if (isset($filters['search'])) {
            $searchTerm = $filters['search'];
            $query->where(function ($q) use ($searchTerm) {
                $q->where('title', 'like', "%$searchTerm%")
                    ->orWhere('description', 'like', "%$searchTerm%")
                    ->orWhere('address', 'like', "%$searchTerm%");
            });
        }

        // Add type filter for student or family
        if (isset($filters['type'])) {
            $query->where(function ($q) use ($filters) {
                $q->where('post_for', $filters['type']);
            });
        }

        return $query->latest();
    }

    public function user()
    {
      return $this->belongsTo(User::class, 'posted_by', 'username');
    }

    public function favoritedBy()
    {
        return $this->belongsToMany(User::class, 'favorites', 'post_id', 'user_id')->withTimestamps();
    }

    public function images()
    {
        return $this->hasMany(Image::class, 'post_id', 'id');
    }

}
