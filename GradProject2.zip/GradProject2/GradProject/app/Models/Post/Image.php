<?php

namespace App\Models\Post;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    use HasFactory;

    protected $fillable = [
        'image_name',
        'post_id'
    ];

    // PostImageController.php
    public function post()
    {
        return $this->belongsTo(Post::class, 'post_id', 'id');
    }
}
