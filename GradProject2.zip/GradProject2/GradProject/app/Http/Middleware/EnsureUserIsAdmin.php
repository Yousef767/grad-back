<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Check if the user is authenticated and their type is 'seller'
        if ($request->user() && $request->user()->user_type === 'admin') {
            return $next($request);
        }

        // If not a seller, return a response indicating unauthorized access
        return response()->json(['error' => 'You are not an admin'], 401);
    }
}
