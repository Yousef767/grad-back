<?php

namespace App\Http\Requests\Post;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdatePostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'sometimes|required|string',
            'post_for' => 'sometimes|required|string|in:student,family' ,
            'description' => 'sometimes|required|string',
            'post_category' => 'sometimes|string',
            'city' => 'sometimes|required|string',
            'address' => 'sometimes|required|string',
            'num_of_bedrooms' => 'sometimes|required|integer',
            'num_of_kitchens' => 'sometimes|required|integer',
            'num_of_bathrooms' => 'sometimes|required|integer',
            'num_of_rooms' => 'sometimes|required|integer',
            'price' => 'sometimes|required|integer',
            'new_images' => 'sometimes|array|max:5', // Max 5 images allowed
            'new_images.*' => 'image|mimes:jpeg,png,jpg,gif|max:5128', // Each image should be a valid image file
               ];
    }
}
