<?php

namespace App\Http\Controllers;

use App\Models\Post\Post;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FavoriteController extends Controller
{

    public function getFavorites(Request $request): \Illuminate\Http\JsonResponse
    {
        $user = Auth::user();
        $favorites = $user->favorites()->latest()->paginate(10); // Paginate the results if needed

        $favorites->transform(function ($favorite) {
            $favorite->date = Carbon::parse($favorite->updated_at)->format('Y-m-d H:i');

            // Assuming you have a relationship like 'images' on your post model
            $imageUrls = $favorite->images->pluck('image_name')->map(function ($imageName) {
                return asset('http://127.0.0.1:8000/images/posts/' . $imageName); // Append the path to each image name
            });

            $favorite->images_urls = $imageUrls; // Appends image URLs to each favorite
            return $favorite;
        });

        $favorites->makeHidden(['created_at', 'updated_at', 'pivot', 'images']); // Hides unnecessary fields

        if ($favorites->isEmpty()) {
            return response()->json(['favorites' => [
                'data' => []
            ]], 200);
        }

        return response()->json(['favorites' => $favorites]);
    }


    public function addToFavorites(Request $request, Post $post): \Illuminate\Http\JsonResponse
    {
        Auth::user()->favorites()->syncWithoutDetaching($post->id);
        return response()->json(['message' => 'Post added to favorites']);
    }

    public function removeFromFavorites(Request $request, Post $post): \Illuminate\Http\JsonResponse
    {
        Auth::user()->favorites()->detach($post->id);
        return response()->json(['message' => 'Post removed from favorites']);
    }
}
