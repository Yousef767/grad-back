<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\CreateUserRequest;
use App\Http\Requests\User\UpdateUserRequest;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminUserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return response()->json($users);
    }

    public function show($id)
    {
        $user = User::findOrFail($id);
        return response()->json($user);
    }

    public function store(CreateUserRequest $request)
    {

        $user = User::create($request->all());

        event(new Registered($user));

        Auth::login($user);

        return response()->json(['message' => 'Created successfully'], 201);
    }

    public function update(UpdateUserRequest $request, $id)
    {
        $user = User::findOrFail($id);
        // Update the user record
        $user->update($request->all());

        // Return a response
        return response()->json(['message' => 'User updated successfully'], 200);
    }

    public function destroy($id)
    {

        if (Auth::user()->id === $id) {
            return response()->json(['message' => 'You can not delete yourself'], 403);
        }

        $user = User::findOrFail($id);
        $user->delete();
        return response()->json([
            'message' => 'User deleted successfully'
        ], 200);
    }
}
