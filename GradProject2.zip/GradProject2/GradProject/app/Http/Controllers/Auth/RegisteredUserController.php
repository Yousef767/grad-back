<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\CreateUserRequest;
use App\Http\Requests\User\UpdateUserRequest;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class RegisteredUserController extends Controller
{
    /**
     * Handle an incoming registration request.
     *
     * @throws ValidationException
     */
    public function store(CreateUserRequest $request): \Illuminate\Http\JsonResponse
    {
        try {
            $validated = $request->validated();

            if ($request->hasFile('profile_image')) {
                $image = $request->file('profile_image');
                $imageName = time() . '_' . $image->getClientOriginalName();
                $image->storeAs('public/profiles', $imageName);
                $validated['user_image'] = $imageName;
            }

            $user = User::create($validated);

            event(new Registered($user));

            Auth::login($user);

            $token = $user->createToken(
                'token-name', ['*'],
                now()->addMonth()
            )->plainTextToken;


            return response()->json([
                'message' => 'User created successfully',
                'user' => $user,
                'token' => $token,

            ], 201);
        } catch (\Exception $e) {
            // Handle exceptions (e.g., validation errors, file upload errors)
            return response()->json([
                'message' => 'An error occurred',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

}
