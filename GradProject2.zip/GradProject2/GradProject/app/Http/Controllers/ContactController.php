<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ContactController extends Controller
{

    public function getAllMessages(): \Illuminate\Http\JsonResponse
    {
        $messages = Contact::latest()->get();

        return response()->json($messages);
    }
    public function storeContactForm(Request $request): \Illuminate\Http\JsonResponse
    {
        // Validation rules can be added here
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'message' => 'required|string|max:1000',
        ]);

        // Create a new ContactUsMessage instance and store the data
        $message = Contact::create($validatedData);

        // Optionally, you can send an email notification or perform other actions here
        if ($message) {
            return response()->json([
                'success' => "message sent successfully",
            ]);
        }

        return response()->json([
            "error" => "could not create message",
        ]);
    }
}
