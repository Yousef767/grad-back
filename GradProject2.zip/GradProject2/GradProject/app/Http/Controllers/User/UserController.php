<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpdateUserRequest;
use App\Models\User;
use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;


class UserController extends Controller
{

    public function show(User $user): \Illuminate\Http\JsonResponse
    {
        Gate::authorize('view', $user);


        $image_name = null;

        if ($user->user_image) {
            $image_name = env('APP_URL') . '/images/profiles/' .  $user->user_image;
        }


        $userData = [
            'name' => $user->name,
            'username' => $user->username ,
            'email' => $user->email,
            'phone' => $user->phone,
            'user_type' => $user->user_type,
            'profile_image' => $image_name,

        ];

        return Response::json(['user' => $userData], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, User $user): \Illuminate\Http\JsonResponse
    {

        Gate::authorize('update', $user);

        $validated = $request->validated();

        if ($request->hasFile('profile_image') && $request->file('profile_image')->isValid()) {

            $request->validate([
                'profile_image' => 'sometimes|image|mimes:jpeg,png,jpg,gif|max:2048', // Adjust max size as needed
            ]);
            // Scenario 1: User sends a profile image in the request
            if ($user->user_image) {
                $imagePath = 'public/profiles/' . $user->user_image;
                if (Storage::exists($imagePath)) {
                    Storage::delete($imagePath); // Delete existing image from storage
                }
            }
            $imageName = time() . '_' . $request->file('profile_image')->getClientOriginalName();
            $request->file('profile_image')->storeAs('public/profiles', $imageName);
            $validated['user_image'] = $imageName;
        } elseif ($request->has('profile_image') && $request->input('profile_image') === null) {
            // Scenario 2: User sends an empty profile image (remove existing image)
            if ($user->user_image) {
                $imagePath = 'public/profiles/' . $user->user_image;
                if (Storage::exists($imagePath)) {
                    Storage::delete($imagePath); // Delete existing image from storage
                    $validated['user_image'] = null; // Clear the user_image attribute in the database
                }
            }
        }

        // Update the user record
        $user->update($validated);

        // Return a response
        return response()->json(['message' => 'User updated successfully'], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user): \Illuminate\Http\JsonResponse
    {
        Gate::authorize('delete', $user);

        $user->delete();

        return response()->json(['message' => 'User deleted successfully'], 200);

    }
}
