<?php

namespace App\Http\Controllers\Post;

use App\Http\Controllers\Controller;
use App\Http\Requests\Post\CreatePostRequest;
use App\Http\Requests\Post\UpdatePostRequest;
use App\Models\Post\Post;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;


class PostController extends Controller
{
    public function index(Request $request): \Illuminate\Http\JsonResponse
    {
        $filters = $request->only(['min_price', 'max_price', 'city', 'num_of_bedrooms', 'num_of_kitchens', 'num_of_bathrooms', 'num_of_rooms', 'search', 'post_category' ,'post_for']);

        $posts = Post::filter($filters)->latest()->paginate(6);
        $posts->getCollection()->transform(function ($post) {
            $post->date = Carbon::parse($post->updated_at)->format('Y-m-d H:i');

            // Transform image paths to include /images/posts/image
            $post->image_names = $post->images->pluck('image_name')->map(function ($path) {
                return 'http://127.0.0.1:8000/images/posts/' .  $path; // Assuming image_path already contains 'posts/image'
            })->toArray();

            return [
                'id' => $post->id,
                'phone' => $post->user->phone,
                'title' => $post->title,
                'post_for' => $post->post_for,
                'post_by' => $post->posted_by,
                'description' => $post->description,
                'post_category' => $post->post_category,
                'city' => $post->city,
                'address' => $post->address,
                'num_of_bedrooms' => $post->num_of_bedrooms,
                'num_of_kitchens' => $post->num_of_kitchens,
                'num_of_bathrooms' => $post->num_of_bathrooms,
                'num_of_rooms' => $post->num_of_rooms,
                'price' => $post->price,
                'date' => $post->date,
                'image_paths' => $post->image_names,

            ];
        });

        if ($posts->isEmpty()) {
            return response()->json(['data' => []], 200);
        }

        return response()->json($posts);

    }


    public function show(string $id): JsonResponse|array
    {
        $post = Post::find($id);

        if (!$post) {
            return response()->json(['message' => 'Post not found.'], 404);
        }

        $post->date = Carbon::parse($post->updated_at)->format('Y-m-d H:i');

        // Transform image paths to include /images/posts/image
        $post->image_paths = $post->images->pluck('image_name')->map(function ($path) {
            return 'http://127.0.0.1:8000/images/posts/' .  $path; // Assuming image_path already contains 'posts/image'
        })->toArray();

        $post->makeHidden(['created_at', 'updated_at', 'images']);

        return [
            'id' => $post->id,
            'phone' => $post->user->phone,
            'title' => $post->title,
            'post_for' => $post->post_for,
            'post_by' => $post->posted_by,
            'description' => $post->description,
            'city' => $post->city,
            'address' => $post->address,
            'num_of_bedrooms' => $post->num_of_bedrooms,
            'num_of_kitchens' => $post->num_of_kitchens,
            'num_of_bathrooms' => $post->num_of_bathrooms,
            'num_of_rooms' => $post->num_of_rooms,
            'price' => $post->price,
            'date' => $post->date,
            'image_paths' => $post->image_paths,

        ];

    }

    public function store(CreatePostRequest $request): JsonResponse
    {

        $imagesName = [];

        $validatedData = $request->validated();
        $validatedData['posted_by'] = Auth::user()->username;

        // Process each image
        foreach ($request->images as $image) {
            // Store the image
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->storeAs('public/posts', $imageName);
            $imagesName[] = $imageName;
        }

        $post = Post::create($validatedData);

        foreach ($imagesName as $imageName) {
            // Create a new image record in the database
            $post->images()->create([
                'post_id' => $post->id,
                'image_name' => basename($imageName)
            ]);
        }


        return response()->json(['message' => 'Post created successfully'], 201);
    }

    public function update(UpdatePostRequest $request, Post $post): JsonResponse
    {
        // Authorize the update action
        Gate::authorize('update', $post);

        // Get existing image names from the request for deletion
        $imagesToDelete = $request->input('delete_images', []);

        // Delete images specified for deletion
        foreach ($imagesToDelete as $imageName) {
            $image = $post->images()->where('image_name', $imageName); // image from database
            if ($image->exists()) {
                $imagePath = 'public/posts/' . $imageName;
                if (Storage::exists($imagePath)) {
                    Storage::delete($imagePath); // Delete image from storage
                }
                $image->delete();
            } else {
                return response()->json(['message' => 'Deleted Image not found.'], 404);
            }
        }

        // Process and store new images
        if ($request->hasFile('new_images')) {
            foreach ($request->file('new_images') as $image) {
                $imageName = time() . '_' . $image->getClientOriginalName();
                $image->storeAs('public/posts', $imageName);

                $post->images()->create([
                    'post_id' => $post->id,
                    'image_name' => $imageName
                ]);
            }
        }

        // Update the post with validated data
        $post->update($request->validated());

        return response()->json(['message' => 'Post updated successfully']);
    }


    public function destroy(string $id): JsonResponse
    {
        $post = Post::findOrFail($id);

        Gate::authorize('delete', $post);

        $post->delete();

        return response()->json(['message' => 'Post deleted successfully']);
    }

    /**
     * Get all posts created by the authenticated seller.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function userPosts(Request $request): JsonResponse
    {
        // Get the authenticated user (seller)
        $user = Auth::user();

        // Ensure the user is authenticated
        if (!$user) {
            return response()->json(['error' => 'Unauthorized.'], 401);
        }

        // Retrieve all posts created by this seller
        $posts = Post::where('posted_by', $user->username)->latest()->paginate(10);

        if ($posts->isEmpty()) {
            return response()->json(['data' => []], 200);
        }

        foreach ($posts as &$post) {
            $post['date'] = Carbon::parse($post['updated_at'])->format('Y-m-d H:i');

            // Assuming $post['images'] is an array of image paths
            $post['image_paths'] = collect($post['images'])->pluck('image_name')->map(function ($path) {
                return 'http://127.0.0.1:8000/images/posts/' . $path; // Assuming image_path already contains 'posts/image'
            })->toArray();
        }

        $posts->makeHidden(['created_at', 'updated_at' ,'post_image', 'images']);


        return response()->json($posts);
    }

}
