<?php

namespace Database\Factories\Post;

use App\Models\Post\Post;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Post>
 */
class PostFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => fake()->sentence ,
            'post_for' => fake()->randomElement(['student', 'family']),
            'posted_by' => User::all()->random()->username ,
            'description' => fake()->text,
            'post_category' => fake()->unique()->word(),
            'city' => fake()->city,
            'address' => fake()->address,
            'num_of_bedrooms' => fake()->numberBetween(1, 5), // Example range for bedrooms
            'num_of_kitchens' => fake()->numberBetween(1, 2), // Example range for kitchens
            'num_of_bathrooms' => fake()->numberBetween(1, 3), // Example range for bathrooms
            'num_of_rooms' => fake()->numberBetween(4, 10), // Example range for rooms
            'price' => fake()->numberBetween(1000, 5000), // Example range for price
        ];
    }
}
