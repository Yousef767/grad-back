<?php

namespace Database\Seeders;

use App\Models\Post\Image;
use Illuminate\Database\Seeder;

class ImageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $images = Image::factory()->count(5)->create();
    }
}
